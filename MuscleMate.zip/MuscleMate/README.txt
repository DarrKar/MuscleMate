Muscle Mate

Darrian Karimi (dkarimi)
Andy Boulle (aboulle)
David Safirstein (dsafirst)

https://muscle-mate.onrender.com

Muscle Mate is an application that will allow the users to select what body parts they want 
to target within their workout and develop a workout for them with reps and instructions on what to do.

API USED: https://rapidapi.com/apininjas/api/exercises-by-api-ninjas/

Youtube Link: https://youtu.be/Gi2R-2XfXJM